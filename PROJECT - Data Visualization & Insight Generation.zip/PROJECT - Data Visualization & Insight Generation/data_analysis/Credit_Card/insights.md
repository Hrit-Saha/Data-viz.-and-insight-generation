1. Fraudulent transactions are extremely rare compared to legitimate ones, reflecting the real-world scenario where fraud is a small fraction of total transactions.

2. Fraudulent transactions often involve amounts that are either unusually high or very low. Fraudsters might test cards with small amounts before making larger purchases.

3. The use of PCA-transformed features (V1 to V28) indicates the complexity and high dimensionality of the data, common in real-world fraud detection systems to capture subtle patterns.
